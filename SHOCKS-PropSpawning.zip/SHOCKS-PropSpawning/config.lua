Config = {}

Config.Props = {
    {
        model = 'mp005_s_posse_butcher01x',
        coords = vector4(-2587.59, 469.4, 145.73, 282.35)
    },
    {
        model = 's_murdervic01x',
        coords = vector4(-2565.49, 485.28, 143.39, 183.57)
    },
    {
        model = 'p_woodpile02x',
        coords = vector4(-2522.92, 392.05, 149.49, 359.8)
    },
    {
        model = 'p_campfire01x',
        coords = vector4(-2525.81, 391.9, 149.36, 84.77)
    },
    {
        model = 'p_bra_cal_sgn_tress3a',
        coords = vector4(-2566.14, 484.47, 143.5, 183.57)
    }
}
