local spawnedProps = {}

local function loadModel(model)
    local hash = GetHashKey(model)
    if not IsModelValid(hash) then
        print(('[PropSpawner] Invalid model: %s'):format(model))
        return nil
    end

    if not HasModelLoaded(hash) then
        RequestModel(hash)
        while not HasModelLoaded(hash) do
            Wait(10)
        end
    end
    return hash
end

local function cleanupProps()
    for _, obj in pairs(spawnedProps) do
        if DoesEntityExist(obj) then
            DeleteObject(obj)
        end
    end
    spawnedProps = {}
end

local function findGroundZ(x, y, z)
    local rayHandle = StartShapeTestRay(x, y, z + 50.0, x, y, z - 50.0, -1, 0, 0)
    local _, hit, endCoords = GetShapeTestResult(rayHandle)
    if hit then
        return endCoords.z
    else
        return z
    end
end

local function spawnProps()
    cleanupProps()
    for _, prop in pairs(Config.Props) do
        local hash = loadModel(prop.model)
        if hash then
            local x, y, z, heading = prop.coords.x, prop.coords.y, prop.coords.z, prop.coords.w

            local groundZ = findGroundZ(x, y, z)

            local obj = CreateObject(hash, x, y, groundZ - 0.05, true, false, false)
            SetEntityHeading(obj, heading)
            SetEntityAsMissionEntity(obj, true, true)
            FreezeEntityPosition(obj, true)

            table.insert(spawnedProps, obj)
        end
    end
    print('[PropSpawner] Spawned all configured props perfectly on the ground.')
end

AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then
        cleanupProps()
    end
end)

AddEventHandler('onClientResourceStart', function(resource)
    if resource == GetCurrentResourceName() then
        Wait(1000)
        spawnProps()
    end
end)
