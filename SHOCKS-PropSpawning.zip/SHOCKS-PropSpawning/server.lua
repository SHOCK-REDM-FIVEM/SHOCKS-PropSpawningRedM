
AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then
        TriggerClientEvent('SHOCKS-PropSpawner:cleanup', -1)
    end
end)

RegisterNetEvent('SHOCKS-PropSpawner:requestProps', function()
    TriggerClientEvent('SHOCKS-PropSpawner:spawnProps', source)
end)
